<?php
echo '<script src="js/jquery.min.js"></script>
     <script src="style/dist/js/bootstrap.min.js"></script>';
?>
