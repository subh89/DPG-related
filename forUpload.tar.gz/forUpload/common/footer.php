<?php
echo'
<footer>
  <p class="pull-right"><a href="#">Back to top</a></p>
  <p>&copy; 2014 Dpg Company, Inc. &middot; <a href="" href="#">Privacy</a> &middot; <a href="" href="#">Terms</a></p>
</footer>'

?>
